/************************************************************************/
/*																		*/
/*	demo.c	--	Zedboard DMA Demo				 						*/
/*																		*/
/************************************************************************/
/*	Author: Sam Lowe											*/
/*	Copyright 2015, Digilent Inc.										*/
/************************************************************************/
/*  Module Description: 												*/
/*																		*/
/*		This file contains code for running a demonstration of the		*/
/*		DMA audio inputs and outputs on the Zedboard.					*/
/*																		*/
/*																		*/
/************************************************************************/
/*  Notes:																*/
/*																		*/
/*		- The DMA max burst size needs to be set to 16 or less			*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/* 																		*/
/*		8/23/2016(SamL): Created										*/
/*																		*/
/************************************************************************/


#include "demo.h"




#include "audio/audio.h"
#include "dma/dma.h"
#include "intc/intc.h"
#include "userio/userio.h"
#include "iic/iic.h"

/***************************** Include Files *********************************/

#include "xaxidma.h"
#include "xparameters.h"
#include "xil_exception.h"
#include "xdebug.h"
#include "xiic.h"
#include "xaxidma.h"



#ifdef XPAR_INTC_0_DEVICE_ID
 #include "xintc.h"
 #include "microblaze_sleep.h"
#else
 #include "xscugic.h"
#include "sleep.h"
#include "xil_cache.h"
#endif

/************************** Constant Definitions *****************************/

/*
 * Device hardware build related constants.
 */

// Audio constants
// Number of seconds to record/playback
#define NR_SEC_TO_REC_PLAY		40

// ADC/DAC sampling rate in Hz
//#define AUDIO_SAMPLING_RATE		1000
#define AUDIO_SAMPLING_RATE	  48000

// Number of samples to record/playback
#define NR_AUDIO_SAMPLES		(NR_SEC_TO_REC_PLAY*AUDIO_SAMPLING_RATE)

/* Timeout loop counter for reset
 */
#define buf1 0x10100000U

#define RESET_TIMEOUT_COUNTER	10000

#define TEST_START_VALUE	0x0


/**************************** Type Definitions *******************************/


/***************** Macros (Inline Functions) Definitions *********************/


/************************** Function Prototypes ******************************/
#if (!defined(DEBUG))
extern void xil_printf(const char *format, ...);
#endif


/************************** Variable Definitions *****************************/
/*
 * Device instance definitions
 */

static XIic sIic;
static XAxiDma sAxiDma;		/* Instance of the XAxiDma */

static XGpio sUserIO;

#ifdef XPAR_INTC_0_DEVICE_ID
 static XIntc sIntc;
#else
 static XScuGic sIntc;
#endif

//
// Interrupt vector table
#ifdef XPAR_INTC_0_DEVICE_ID
const ivt_t ivt[] = {
	//IIC
	{XPAR_AXI_INTC_0_AXI_IIC_0_IIC2INTC_IRPT_INTR, (XInterruptHandler)XIic_InterruptHandler, &sIic},
	//DMA Stream to MemoryMap Interrupt handler
	{XPAR_AXI_INTC_0_AXI_DMA_0_S2MM_INTROUT_INTR, (XInterruptHandler)fnS2MMInterruptHandler, &sAxiDma},
	//DMA MemoryMap to Stream Interrupt handler
	{XPAR_AXI_INTC_0_AXI_DMA_0_MM2S_INTROUT_INTR, (XInterruptHandler)fnMM2SInterruptHandler, &sAxiDma},
	//User I/O (buttons, switches, LEDs)
	{XPAR_AXI_INTC_0_AXI_GPIO_0_IP2INTC_IRPT_INTR, (XInterruptHandler)fnUserIOIsr, &sUserIO}
};
#else
const ivt_t ivt[] = {
	//IIC
	{XPAR_FABRIC_AXI_IIC_0_IIC2INTC_IRPT_INTR, (Xil_ExceptionHandler)XIic_InterruptHandler, &sIic},
	//DMA Stream to MemoryMap Interrupt handler
	{XPAR_FABRIC_AXI_DMA_0_S2MM_INTROUT_INTR, (Xil_ExceptionHandler)fnS2MMInterruptHandler, &sAxiDma},
	//DMA MemoryMap to Stream Interrupt handler
	{XPAR_FABRIC_AXI_DMA_0_MM2S_INTROUT_INTR, (Xil_ExceptionHandler)fnMM2SInterruptHandler, &sAxiDma},
	//User I/O (buttons, switches, LEDs)
	{XPAR_FABRIC_AXI_GPIO_0_IP2INTC_IRPT_INTR, (Xil_ExceptionHandler)fnUserIOIsr, &sUserIO}
};
#endif


/*****************************************************************************/
/**
*
* Main function
*
* This function is the main entry of the interrupt test. It does the following:
*	Initialize the interrupt controller
*	Initialize the IIC controller
*	Initialize the User I/O driver
*	Initialize the DMA engine
*	Initialize the Audio I2S controller
*	Enable the interrupts
*	Wait for a button event then start selected task
*	Wait for task to complete
*
* @param	None
*
* @return
*		- XST_SUCCESS if example finishes successfully
*		- XST_FAILURE if example fails.
*
* @note		None.
*
******************************************************************************/

int main(void)
{
	enum state {DUMMY,RECORD,RECLOOP,LOOPER} curr_state;




	int Status;

	Demo.u8Verbose = 1;

	//Xil_DCacheDisable();

	xil_printf("\r\n--- Entering main() --- \r\n");


	//
	//Initialize the interrupt controller

	Status = fnInitInterruptController(&sIntc);
	if(Status != XST_SUCCESS) {
		xil_printf("Error initializing interrupts");
		return XST_FAILURE;
	}


	// Initialize IIC controller
	Status = fnInitIic(&sIic);
	if(Status != XST_SUCCESS) {
		xil_printf("Error initializing I2C controller");
		return XST_FAILURE;
	}

    // Initialize User I/O driver
    Status = fnInitUserIO(&sUserIO);
    if(Status != XST_SUCCESS) {
    	xil_printf("User I/O ERROR");
    	return XST_FAILURE;
    }


	//Initialize DMA
	Status = fnConfigDma(&sAxiDma);
	if(Status != XST_SUCCESS) {
		xil_printf("DMA configuration ERROR");
		return XST_FAILURE;
	}


	//Initialize Audio I2S
	Status = fnInitAudio();
	if(Status != XST_SUCCESS) {
		xil_printf("Audio initializing ERROR");
		return XST_FAILURE;
	}


	// Enable all interrupts in our interrupt vector table
	// Make sure all driver instances using interrupts are initialized first
	fnEnableInterrupts(&sIntc, &ivt[0], sizeof(ivt)/sizeof(ivt[0]));



    xil_printf("\r\nInitialization done");
    xil_printf("\r\n");
    xil_printf("\r\nControls:");
    xil_printf("\r\n    BTNL: Play recording on LINE OUT");
    xil_printf("\r\n    BTNU: Record from MIC IN");
    xil_printf("\r\n    BTND: Play recording on HPH OUT");
    xil_printf("\r\n    BTNR: Record from LINE IN");

    //main loop

    u32 remaining = 0;
    while(1) {


//    	xil_printf("----------------------------------------------------------\r\n");
//		xil_printf("Genesys 2 DMA Audio Demo\r\n");
//		xil_printf("----------------------------------------------------------\r\n");

    	//Xil_DCacheDisable();

    	// Checking the DMA S2MM event flag
    			if (Demo.fDmaS2MMEvent)
    			{
    				xil_printf("\r\nRecording Done...");
//    				remaining = XAxiDma_ReadReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + 0x28);
//    				xil_printf("Bytes remaining in request: %u\n", remaining);

    				// Disable Stream function to send data (S2MM)
    				Xil_Out32(I2S_STREAM_CONTROL_REG, 0x00000000);
    				Xil_Out32(I2S_TRANSFER_CONTROL_REG, 0x00000000);
    				//Flush cache
    				//Flush cache


//					//microblaze_flush_dcache();
					//Xil_DCacheInvalidateRange((u32) MEM_BASE_ADDR, 5*NR_AUDIO_SAMPLES);
    				//microblaze_invalidate_dcache();
    				// Reset S2MM event and record flag
    				Demo.fDmaS2MMEvent = 0;
    				Demo.fAudioRecord = 0;
    			}

    			// Checking the DMA MM2S event flag
    			if (Demo.fDmaMM2SEvent)
    			{
    				xil_printf("\r\nPlayback Done...");

    				// Disable Stream function to send data (S2MM)
    				Xil_Out32(I2S_STREAM_CONTROL_REG, 0x00000000);
    				Xil_Out32(I2S_TRANSFER_CONTROL_REG, 0x00000000);
    				//Flush cache
//					//microblaze_flush_dcache();
    				//Xil_DCacheFlushRange((u32) MEM_BASE_ADDR, 5*NR_AUDIO_SAMPLES);
    				// Reset MM2S event and playback flag
    				Demo.fDmaMM2SEvent = 0;
    				Demo.fAudioPlayback = 0;
    			}

    			// Checking the DMA Error event flag
    			if (Demo.fDmaError)
    			{
    				xil_printf("\r\nDma Error...");
    				xil_printf("\r\nDma Reset...");


    				Demo.fDmaError = 0;
    				Demo.fAudioPlayback = 0;
    				Demo.fAudioRecord = 0;
    			}

    			// Checking the btn change event
    			if(Demo.fUserIOEvent) {

    				switch(Demo.chBtn) {
//
    					case 'c':


    						//XAxiDma_Reset(&sAxiDma);
    						//gently send a tlast sig to stop recording.
//    						Xil_Out8(XPAR_GPIO_1_BASEADDR,0x1);
//    				//		while (!(XAxiDma_ReadReg(XPAR_AXI_DMA_0_BASEADDR, 0x34) & XAXIDMA_IDLE_MASK));
//    						Xil_Out8(XPAR_GPIO_1_BASEADDR,0x0);

//    	    				xil_printf("\r\nRecording Done...");
//    	    				remaining = XAxiDma_ReadReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + 0x28);
//    	    				xil_printf("Bytes remaining in request: %u\n", remaining);
//
//    						XAxiDma_Reset(&sAxiDma);
//    						while (XAxiDma_ResetIsDone(&sAxiDma) == 0);
//
//    						fnConfigDma(&sAxiDma);
//    						Xil_Out32(XPAR_AXI_DMA_0_BASEADDR + 0x30,Xil_In32(XPAR_AXI_DMA_0_BASEADDR + 0x30) | 0x1);


    						//may need error check to prevent issue here?

//    						Demo.fAudioRecord = 0;
//    						Demo.fAudioPlayback = 0;
    						break;

    					case 'r':
    						if (!Demo.fAudioRecord && !Demo.fAudioPlayback)
    						{
    							//xil_printf("\r\nStart Recording...\r\n");
    							fnSetLineInput();





    							//fnAudioRecord(sAxiDma,NR_AUDIO_SAMPLES,buf1);

    							//recording start. this is involved, so keep up, yeah?
    							//basically we need a max of 2 minutes of record time. we also need to be able to stop this whenever.
    							//i did previously try to use HW to get a nice clean interrupt, but that sucked ass.
    							//it was inconsistent and played with the HW too much and kinda defeated the whole purpose of doing it
    							//in hw to begin with.

    							//essentially we're just going to do 11250 samples that consist of 4096 samples each.
    							//we'll check for stops in the loop itself. obviously, this will cause around 80 ms of latency.
    							//i understand this isnt incredibly desirable, but i think it's fine. humans have at max like 100ms of
    							//response time, so it's OK. mine's like 200ms visually.
    							//this is also necessary if we want the rest of the functionality to work properly, which i can explain later.

    							for(int i = 0; i < 352; i++){
    								xil_printf("%d\n",i);
    								//record 4096 bytes, offset them in memory by 4096.

//    							    if (Xil_In32(0x40400034) & 0x7073) {  // Clear errors + IOC + halt
//    							        Xil_Out32(0x40400034, 0x7073);
//    							        usleep(100);
//    							    }


    								fnSetLineInput();

    								fnAudioRecord(sAxiDma,4096,((UINTPTR)buf1 + 4096 * 4 * i));
    								//need to wait until DMA is ready!
    								Demo.fAudioRecord = 1;
    								//while(!(0x00000002 & Xil_In32(0x40400034)));
    								while(Demo.fDmaS2MMEvent == 0);
    								//xil_printf("\r\nRecording Done...");
    								//    				remaining = XAxiDma_ReadReg(XPAR_AXI_DMA_0_BASEADDR, XAXIDMA_RX_OFFSET + 0x28);
    								//    				xil_printf("Bytes remaining in request: %u\n", remaining);
    								    				// Disable Stream function to send data (S2MM)
    								    				Xil_Out32(I2S_STREAM_CONTROL_REG, 0x00000000);
    								    				Xil_Out32(I2S_TRANSFER_CONTROL_REG, 0x00000000);
    								    				//Flush cache
    								    				//Flush cache


    								    				//wait for interrupt!

    								//					//microblaze_flush_dcache();
    													//Xil_DCacheInvalidateRange((u32) MEM_BASE_ADDR, 5*NR_AUDIO_SAMPLES);
    								    				//microblaze_invalidate_dcache();
    								    				// Reset S2MM event and record flag
    								    				Demo.fDmaS2MMEvent = 0;
    								    				Demo.fAudioRecord = 0;
//    								Xil_Out32(0x40400034, 0x00000002);

    							}

    						}
    						else
    						{
    							if (Demo.fAudioRecord)
    							{
    								xil_printf("\r\nStill Recording...\r\n");
    							}
    							else
    							{
    								xil_printf("\r\nStill Playing back...\r\n");
    							}
    						}
    						break;
    					case 'l':
    						if (!Demo.fAudioRecord && !Demo.fAudioPlayback)
    						{
    							xil_printf("\r\nStart Playback...");
    							fnSetLineOutput();
    							fnAudioPlay(sAxiDma,NR_AUDIO_SAMPLES);
    							//need to make variable to track # of samples (i.e., when do we stop recording?)

    							Demo.fAudioPlayback = 1;
    						}
    						else
    						{
    							if (Demo.fAudioRecord)
    							{
    								xil_printf("\r\nStill Recording...\r\n");
    							}
    							else
    							{
    								xil_printf("\r\nStill Playing back...\r\n");
    							}
    						}
    						break;
    					default:
    						break;
    				}

    				// Reset the user I/O flag
    				Demo.chBtn = 0;
    				Demo.fUserIOEvent = 0;


    			}
    	//usleep(90000);

    	switch(curr_state){

    	case(DUMMY):
    		break;
    	case(RECORD):
    		//do some recording shit here meow
    		//basically just start recording audio for like 2 minutes at MAX or interrupt it and end it early if specified

    		break;
    	case(RECLOOP):
    		//record and loop muthafuckaaaa!!
    		break;
    	case(LOOPER):
			//just loop fivever
			break;
    	default:
    		//
    		break;







    	}

    }

	xil_printf("\r\n--- Exiting main() --- \r\n");


	return XST_SUCCESS;

}









